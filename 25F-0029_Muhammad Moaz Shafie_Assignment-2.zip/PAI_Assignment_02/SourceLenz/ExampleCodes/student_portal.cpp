#include <iostream>
#include <string>

using namespace std;

// Represents basic information about a student
class Student {
private:
    string name;
    int studentId;
    double average;

public:
    void setAverage(double value) {
        average = value;
    }

    double getAverage() {
        return average;
    }
};

// Stores basic information about a course
class Course {
private:
    string courseName;
    int enrolledStudents;

public:
    void setEnrollment(int count) {
        enrolledStudents = count;
    }

    int getEnrollment() {
        return enrolledStudents;
    }
};

// Calculates the average of the supplied marks
double calculateAverage(int marks[6], int count) {
    int total = 0;

    for (int i = 0; i < count; i++) {
        total = total + marks[i];
    }

    double average = total / count;

    return average;
}

void displayPerformance(double average) {
    if (average >= 80) {
        cout << "Excellent" << endl;
    }
    else if (average >= 60) {
        cout << "Good" << endl;
    }
    else if (average >= 50) {
        cout << "Satisfactory" << endl;
    }
    else {
        cout << "Needs improvement" << endl;
    }
}

int main() {
    int marks[6];
    int count = 0;
    bool collecting = true;
    string courseName = "Programming for AI";
    double* averagePointer;

    // Collect marks for the current course
    while (collecting) {
        int mark;

        cout << "Enter mark (-1 to finish): ";
        cin >> mark;

        if (mark < 0) {
            collecting = false;
        }
        else {
            marks[count] = mark;
            count = count + 1;
        }

        if (count == 6) {
            collecting = false;
        }
    }

    if (count > 0) {
        double average = calculateAverage(marks, count);
        displayPerformance(average);
    }
    else {
        cout << "No marks entered" << endl;
    }

    return 0;
}