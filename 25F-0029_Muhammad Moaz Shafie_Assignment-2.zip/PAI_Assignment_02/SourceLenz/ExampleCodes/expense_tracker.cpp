#include <iostream>
#include <string>

using namespace std;

// Stores information about one expense
class Expense {
private:
    string description;
    double amount;
    bool paid;

public:
    void setAmount(double newAmount) {
        amount = newAmount;
    }

    double getAmount() {
        return amount;
    }

    bool isPaid() {
        return paid;
    }
};

// Calculates the total value stored in an expense array
double calculateTotal(double expenses[5], int count) {
    double total = 0.0;

    for (int i = 0; i < count; i++) {
        total = total + expenses[i];
    }

    return total;
}

void printBudgetStatus(double total, double budget) {
    if (total > budget) {
        cout << "Budget exceeded" << endl;
    }
    else if (total == budget) {
        cout << "Budget fully used" << endl;
    }
    else {
        cout << "Budget available" << endl;
    }
}

int main() {
    double expenses[5];
    double budget = 500.0;
    int count = 0;
    bool running = true;

    while (running) {
        double amount;

        cout << "Enter expense amount: ";
        cin >> amount;

        if (amount < 0) {
            running = false;
        }
        else {
            expenses[count] = amount;
            count = count + 1;
        }

        if (count == 5) {
            running = false;
        }
    }

    double total = calculateTotal(expenses, count); // calculating total
    printBudgetStatus(total, budget);

    cout << "Total expenses: " << total << endl;

    return 0;
}