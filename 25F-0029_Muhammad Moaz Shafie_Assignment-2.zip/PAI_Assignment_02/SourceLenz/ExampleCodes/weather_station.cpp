#include <iostream>
#include <string>

using namespace std;

// Stores and processes readings from a weather station
class WeatherStation {
private:
    string stationName;
    float currentTemperature;
    double pressure;
    bool active;
    float readings[7];

public:
    void showTemperatureStatus() {
        if (currentTemperature >= 35) {
            cout << "Temperature Status: HOT" << endl;
        }
        else if (currentTemperature <= 10) {
            cout << "Temperature Status: COLD" << endl;
        }
        else {
            cout << "Temperature Status: NORMAL" << endl;
        }
    }

    double getPressure() {
        return pressure;
    }

    bool isActive() {
        return active;
    }
};

// Calculates the average temperature recorded during the week
float calculateAverage(float readings[7], int totalReadings) {
    float total = 0.0;
    int index = 0;

    while (index < totalReadings) {
        total = total + readings[index];
        index = index + 1;
    }

    return total / totalReadings;
}

int main() {
    float weeklyReadings[7];
    int totalReadings = 7;
    int hotDays = 0;
    float averageTemperature = 0.0;
    double currentPressure = 1013.25;
    double* pressurePtr;

    pressurePtr = &currentPressure;

    // Read temperature values for one week
    for (int i = 0; i < totalReadings; i++) {
        cout << "Enter temperature for day " << i + 1 << ": ";
        cin >> weeklyReadings[i];

        if (weeklyReadings[i] >= 35) {
            hotDays = hotDays + 1;
        }
    }

    averageTemperature = calculateAverage(weeklyReadings, totalReadings);

    cout << "Average temperature: " << averageTemperature << endl;
    cout << "Number of hot days: " << hotDays << endl;
    cout << "Atmospheric pressure: " << *pressurePtr << endl;

    return 0;
}