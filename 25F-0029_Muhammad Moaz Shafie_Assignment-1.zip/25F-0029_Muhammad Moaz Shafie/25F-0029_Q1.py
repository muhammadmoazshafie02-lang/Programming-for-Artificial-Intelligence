Keywords = ["urgent", "emergency", "alert", "confidential", "security"]

def Character_Frequency(Message):
    Frequency = {}
    for Char in Message:
        if Char != " ":
            Char = Char.lower()
            if Char in Frequency:
                Frequency[Char] += 1
            else:
                Frequency[Char] = 1

    Odd_Count = 0
    for Char in Frequency:
        if Frequency[Char] % 2 != 0:
            Odd_Count += 1
    if Odd_Count == 0:
        Message_Type = "Type A - Can be converted into palindrome"
    elif Odd_Count == 1:
        Message_Type = "Type B - Can be converted into palindrome"
    else:
        Message_Type = "Type C - Cannot be converted into palindrome"
    return Frequency, Message_Type

def Clean_Spaces(Message):
    return " ".join(Message.split())

def Scramble_Words(Message):
    Words = Message.split()
    for i in range(1, len(Words), 2):
        Words[i] = Words[i][::-1]
    return " ".join(Words)

def Remove_Duplicates(Message):
    Result = ""
    Seen = set()
    for Char in Message:
        if Char == " ":
            Result += Char
        elif Char not in Seen:
            Result += Char
            Seen.add(Char)
    return " ".join(Result.split())

def Reverse_Words(Message):
    Words = Message.split()
    Words.reverse()
    return " ".join(Words)

def Validate_Content(Message):
    Text = Message.replace(" ", "")
    if Text.isalpha():
        return "Letters only"
    elif Text.isdigit():
        return "Numbers only"
    elif Text.isalnum():
        return "Alphanumeric"
    else:
        return "Contains letters/numbers/symbols"

def Check_Case(Message):
    Words = Message.split()
    if not Words:
        return "Empty"
    if Message.isupper():
        return "Uppercase"
    elif Message.islower():
        return "Lowercase"
    elif all(Word[0].isupper() for Word in Words if Word):
        return "Title Case"
    else:
        return "Mixed Case"

def Find_Keywords(Message):
    Results = {}
    Lower_Message = Message.lower()
    for Keyword in Keywords:
        Positions = []
        Start = 0
        while True:
            Position = Lower_Message.find(Keyword, Start)
            if Position == -1:
                break
            Positions.append(Position)
            Start = Position + len(Keyword)
        if Positions:
            Results[Keyword] = Positions
    return Results

def Calculate_Priority(Keyword_Info):
    Score = 0
    for Keyword in Keyword_Info:
        Count = len(Keyword_Info[Keyword])
        if Keyword == "emergency":
            Score += 10 * Count
        elif Keyword == "urgent":
            Score += 9 * Count
        elif Keyword == "security":
            Score += 7 * Count
        elif Keyword == "alert":
            Score += 6 * Count
        elif Keyword == "confidential":
            Score += 5 * Count
        for Position in Keyword_Info[Keyword]:
            if Position < 10:
                Score += 2
    return Score

def Analyze_Message(Message):
    print("\n" + "=" * 70)
    print("1. Original Message:")
    print(Message)

    Cleaned = Clean_Spaces(Message)
    print("\n2. After Removing Unnecessary Spaces:")
    print(Cleaned)

    Frequency, Message_Type = Character_Frequency(Cleaned)
    print("\n3. Character Frequency:")
    for Char in Frequency:
        print("'" + Char + "':", Frequency[Char])

    print("\n4. Palindrome Classification:")
    print(Message_Type)

    Scrambled = Scramble_Words(Cleaned)
    print("\n5. After Reversing Every Second Word:")
    print(Scrambled)

    No_Duplicates = Remove_Duplicates(Scrambled)
    print("\n6. After Removing Duplicate Characters:")
    print(No_Duplicates)

    Reversed_Message = Reverse_Words(No_Duplicates)
    print("\n7. After Reversing Order of Words:")
    print(Reversed_Message)

    print("\n8. Content Validation:")
    print(Validate_Content(Cleaned))

    print("\n9. Case Format:")
    print(Check_Case(Cleaned))

    Keyword_Info = Find_Keywords(Message)
    print("\n10. Important Keywords Found:")

    if not Keyword_Info:
        print("No important keywords found.")
    else:
        for Keyword in Keyword_Info:
            print(Keyword.capitalize())

    print("\n11. Keyword Frequency and Positions:")

    if not Keyword_Info:
        print("No keywords found.")
    else:
        for Keyword in Keyword_Info:
            print(
                Keyword.capitalize(),
                "-> Frequency:", len(Keyword_Info[Keyword]),
                "| Positions:", Keyword_Info[Keyword]
            )

    Priority = Calculate_Priority(Keyword_Info)

    if Priority >= 15:
        Priority_Level = "HIGH"
    elif Priority >= 7:
        Priority_Level = "MEDIUM"
    else:
        Priority_Level = "LOW"

    print("\n12. Priority:")
    print(Priority_Level, "(Score:", Priority, ")")
    return Message, Priority, Priority_Level

Messages = [
    "   URGENT    SECURITY ALERT   ",
    "Confidential    Data Transfer",
    "Emergency Response Required",
    "Routine    Department Meeting",
    "ALERT Security Breach",
    "CONFIDENTIAL REPORT 2026",
    "Emergency Communication Required!!!"
]

Results = []

print("=" * 70)
print("       GOVERNMENT MESSAGE ANALYSIS SYSTEM")
print("=" * 70)

for Message in Messages:
    Result = Analyze_Message(Message)
    Results.append(Result)

print("\n" + "=" * 70)
print("              FINAL PRIORITY COMPARISON")
print("=" * 70)

for i in range(len(Results)):
    for j in range(i + 1, len(Results)):
        if Results[i][1] < Results[j][1]:
            Results[i], Results[j] = Results[j], Results[i]

Rank = 1
for Result in Results:
    print(
        Rank, ".",
        Result[0],
        "->", Result[2],
        "(Score:", Result[1], ")"
    )
    Rank += 1