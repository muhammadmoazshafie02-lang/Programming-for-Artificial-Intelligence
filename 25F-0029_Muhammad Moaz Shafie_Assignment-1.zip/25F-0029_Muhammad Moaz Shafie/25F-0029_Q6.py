import random

ASCII_Dict = {}

for i in range(128):
    ASCII_Dict[chr(i)] = i

def Convert_Value(Value):
    if isinstance(Value, str):
        if len(Value) > 1:
            print("Bring your elder brother")
            exit()
        elif len(Value) == 1:
            Value = ASCII_Dict[Value]
        else:
            print("Can't help you more little kid!")
            exit()
    elif isinstance(Value, float):
        Value = round(Value)
    elif isinstance(Value, int):
        pass
    else:
        print("Can't help you more little kid!")
        exit()
    if Value > 100:
        Value = 100
    elif Value < 0:
        Value = 0
    return Value

def Convert_Matrix(Matrix):
    New_Matrix = []
    for Row in Matrix:
        New_Row = []
        for Value in Row:
            Converted = Convert_Value(Value)
            New_Row.append(Converted)
        New_Matrix.append(New_Row)
    return New_Matrix

def Input_Matrix(Name):
    Matrix = []
    print("Enter Matrix", Name, "row by row.")
    print("Enter values separated by spaces.")
    print("Enter done when Matrix", Name, "is complete.")
    while True:
        Row = input("Enter row: ")
        if Row == "done":
            break
        Values = Row.split()
        New_Row = []
        for Value in Values:
            if "." in Value:
                New_Row.append(float(Value))
            elif Value.isdigit():
                New_Row.append(int(Value))
            else:
                New_Row.append(Value)
        Matrix.append(New_Row)
    return Matrix

def Pad_Rows(Matrix):
    Max_Columns = max(len(Row) for Row in Matrix)
    for Row in Matrix:
        while len(Row) < Max_Columns:
            Row.append(0)
    return Matrix

def Make_Dimensions_Compatible(A, B):
    A = Pad_Rows(A)
    B = Pad_Rows(B)
    Columns_A = len(A[0])
    Rows_B = len(B)
    if Columns_A > Rows_B:
        while len(B) < Columns_A:
            B.append([0] * len(B[0]))
    elif Columns_A < Rows_B:
        while len(A[0]) < Rows_B:
            for Row in A:
                Row.append(0)
    return A, B

def Matrix_Multiply(A, B):
    Result = []
    for Row in A:
        New_Row = [
            sum(Row[k] * B[k][j] for k in range(len(B)))
            for j in range(len(B[0]))
        ]
        Result.append(New_Row)
    return Result

def Swap_First_Last(Matrix):
    if len(Matrix) > 1:
        Matrix[0], Matrix[-1] = Matrix[-1], Matrix[0]
    if len(Matrix[0]) > 1:
        for Row in Matrix:
            Row[0], Row[-1] = Row[-1], Row[0]
    return Matrix

def RREF(Matrix):
    Matrix = [Row[:] for Row in Matrix]
    Rows = len(Matrix)
    Columns = len(Matrix[0])
    Pivot_Row = 0
    for Col in range(Columns):
        Pivot = -1
        for i in range(Pivot_Row, Rows):
            if Matrix[i][Col] != 0:
                Pivot = i
                break
        if Pivot == -1:
            continue
        Matrix[Pivot_Row], Matrix[Pivot] = Matrix[Pivot], Matrix[Pivot_Row]
        Pivot_Value = Matrix[Pivot_Row][Col]
        for j in range(Columns):
            Matrix[Pivot_Row][j] /= Pivot_Value
        for i in range(Rows):
            if i != Pivot_Row:
                Factor = Matrix[i][Col]
                for j in range(Columns):
                    Matrix[i][j] -= Factor * Matrix[Pivot_Row][j]
        Pivot_Row += 1
        if Pivot_Row == Rows:
            break
    return Matrix

def Check_Column_Space(M, R):
    print("\nColumn Space Test")
    print("=" * 50)
    for j in range(len(R[0])):
        r = [R[i][j] for i in range(len(R))]
        Augmented = [
            M[i][:] + [r[i]]
            for i in range(len(M))
        ]
        Reduced = RREF(Augmented)
        Possible = True
        for Row in Reduced:
            if all(x == 0 for x in Row[:-1]):
                if Row[-1] != 0:
                    Possible = False
        print("\nR Column", j + 1, ":", r)
        if Possible:
            print("Can be represented as a Linear Combination.")
        else:
            print("Cannot be represented as a Linear Combination.")

print("===== MATRIX A INPUT =====")
Matrix_A = Input_Matrix("A")

print("\n===== MATRIX B INPUT =====")
Matrix_B = Input_Matrix("B")

Matrix_A = Convert_Matrix(Matrix_A)
Matrix_B = Convert_Matrix(Matrix_B)

print("\nConverted Matrix A:")
print(Matrix_A)
print("\nConverted Matrix B:")
print(Matrix_B)

Matrix_A, Matrix_B = Make_Dimensions_Compatible(Matrix_A, Matrix_B)

print("\nDimension Fixed Matrix A:")
print(Matrix_A)
print("\nDimension Fixed Matrix B:")
print(Matrix_B)

M = Matrix_Multiply(Matrix_A, Matrix_B)

print("\nMatrix Multiplication Result:")
print(M)

M = Swap_First_Last(M)

print("\nUpdated Resultant Matrix M:")
print(M)

R = [
    [random.randint(1, 100) for j in range(len(M[0]))]
    for i in range(len(M))
]

print("\nRandom Matrix R:")
print(R)
Check_Column_Space(M, R)