import math

Store1 = (1000, 0.05, 4, 24)
Store2 = (1500, 0.045, 12, 24)
Store3 = (1200, 0.06, 1, 24)

def Calculate_Store(Store):
    B = Store[0]
    r = Store[1]
    n = Store[2]
    t = Store[3]

    Discrete = B * (1 + r / n) ** (n * t)
    Continuous = B * math.exp(r * t)
    Increase = ((Discrete - B) / B) * 100

    if Increase < 200 and not (Increase >= 200):
        Risk = "Low Load"
    elif Increase >= 200 and Increase <= 250:
        Risk = "Moderate Load"
    elif Increase > 250 or not (Increase <= 250):
        Risk = "High Load"

    Scaled_Rate = int(r * 10000)
    Surge_Rate = (Scaled_Rate << 1) / 10000
    Throttle_Rate = (Scaled_Rate >> 1) / 10000
    return B, r, n, t, Discrete, Continuous, Increase, Risk, Scaled_Rate, Surge_Rate, Throttle_Rate

Result1 = Calculate_Store(Store1)
Result2 = Calculate_Store(Store2)
Result3 = Calculate_Store(Store3)

def Display_Report(Name, Result):
    print("\n" + "=" * 50)
    print(Name)
    print("=" * 50)
    print("Baseline Requests/sec:", Result[0])
    print("Growth Rate:", Result[1])
    print("Growth Updates/hour:", Result[2])
    print("Monitoring Duration:", Result[3], "hours")
    print("Discrete Projected Load:", round(Result[4], 2))
    print("Continuous Projected Load:", round(Result[5], 2))
    print("Load Increase Percentage:", round(Result[6], 2), "%")
    print("Load Risk:", Result[7])
    print("Surge-Adjusted Growth Rate:", Result[9])
    print("Throttled Growth Rate:", Result[10])

Display_Report("STORE 1", Result1)
Display_Report("STORE 2", Result2)
Display_Report("STORE 3", Result3)

Load1 = Result1[4]
Load2 = Result2[4]
Load3 = Result3[4]

print("\n" + "=" * 50)
print("PROJECTED LOAD COMPARISON")
print("=" * 50)
print("Store 1 > Store 2:", Load1 > Load2)
print("Store 1 < Store 2:", Load1 < Load2)
print("Store 1 == Store 2:", Load1 == Load2)
print("Store 1 > Store 3:", Load1 > Load3)
print("Store 1 < Store 3:", Load1 < Load3)
print("Store 1 == Store 3:", Load1 == Load3)
print("Store 2 > Store 3:", Load2 > Load3)
print("Store 2 < Store 3:", Load2 < Load3)
print("Store 2 == Store 3:", Load2 == Load3)

if Load1 > Load2 and Load1 > Load3:
    Highest = "Store 1"
elif Load2 > Load1 and Load2 > Load3:
    Highest = "Store 2"
else:
    Highest = "Store 3"

if Load1 < Load2 and Load1 < Load3:
    Lowest = "Store 1"
elif Load2 < Load1 and Load2 < Load3:
    Lowest = "Store 2"
else:
    Lowest = "Store 3"

print("\nHighest Projected Load:", Highest)
print("Lowest Projected Load:", Lowest)

print("\n" + "=" * 50)
print("ARITHMETIC OPERATORS")
print("=" * 50)

A = 20
B = 6

print("Addition (+):", A + B)
print("Subtraction (-):", A - B)
print("Multiplication (*):", A * B)
print("Division (/):", A / B)
print("Modulus (%):", A % B)
print("Floor Division (//):", A // B)
print("Power (**):", A ** 2)

print("\n" + "=" * 50)
print("LOGICAL OPERATORS")
print("=" * 50)

X = True
Y = False

print("AND:", X and Y)
print("OR:", X or Y)
print("NOT:", not X)

print("\n" + "=" * 50)
print("BITWISE OPERATORS")
print("=" * 50)

Flagged_Traffic_Rate = 500
Traffic_Surge = 1

print("Original:", Flagged_Traffic_Rate)
print("AND (&):", Flagged_Traffic_Rate & Traffic_Surge)
print("OR (|):", Flagged_Traffic_Rate | Traffic_Surge)
print("XOR (^):", Flagged_Traffic_Rate ^ Traffic_Surge)
print("NOT (~):", ~Flagged_Traffic_Rate)
print("Left Shift (<<):", Flagged_Traffic_Rate << 1)
print("Right Shift (>>):", Flagged_Traffic_Rate >> 1)

print("\n" + "=" * 50)
print("TRAFFIC SURGE AND THROTTLING")
print("=" * 50)

Flagged_Traffic_Rate = 500
Traffic_Surge = 1

Flagged_Traffic_Rate = Flagged_Traffic_Rate | Traffic_Surge
print("Surge Flag ON:", Flagged_Traffic_Rate)
Flagged_Traffic_Rate = Flagged_Traffic_Rate ^ Traffic_Surge
print("After Toggling:", Flagged_Traffic_Rate)
Flagged_Traffic_Rate = Flagged_Traffic_Rate & ~Traffic_Surge
print("After Clearing:", Flagged_Traffic_Rate)

print("\n" + "=" * 50)
print("FINAL SUMMARY")
print("=" * 50)
print("Highest Projected Load:", Highest)
print("Lowest Projected Load:", Lowest)
print("Store 1 Discrete Load:", round(Load1, 2))
print("Store 2 Discrete Load:", round(Load2, 2))
print("Store 3 Discrete Load:", round(Load3, 2))