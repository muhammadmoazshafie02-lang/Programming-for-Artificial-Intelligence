Project_Tasks = [
    ["Task A", "incomplete", [
        ["Subtask A1", "completed", []],
        ["Subtask A2", "incomplete", [
            ["Subtask A2a", "completed", []],
            ["Subtask A2b", "incomplete", []]
        ]]
    ]],
    ["Task B", "incomplete", [
        ["Subtask B1", "incomplete", []],
        ["Subtask B2", "completed", [
            ["Subtask B2a", "incomplete", []]
        ]]
    ]],
    ["Task C", "completed", [
        ["Subtask C1", "completed", []],
        ["Subtask C2", "completed", [
            ["Subtask C2a", "completed", []],
            ["Subtask C2b", "incomplete", [
                ["Subtask C2b1", "completed", []]
            ]]
        ]]
    ]]
]

Shallow_Copy = Project_Tasks[:]
Shallow_Copy[0][1] = "completed"

print("After Changing Task A in Shallow Copy:")
print("Original Task A Status:", Project_Tasks[0][1])
print("Shallow Copy Task A Status:", Shallow_Copy[0][1])
print("Both Changed because the Inner Lists are Shared.")

def Manual_Deep_Copy(Tasks):
    New_Tasks = []
    for Task in Tasks:
        New_Task = [Task[0], Task[1], []]
        for Subtask in Task[2]:
            New_Subtask = [Subtask[0], Subtask[1], []]
            for Nested in Subtask[2]:
                New_Nested = [Nested[0], Nested[1], []]
                for Deeper in Nested[2]:
                    New_Nested[2].append([Deeper[0], Deeper[1], []])
                New_Subtask[2].append(New_Nested)
            New_Task[2].append(New_Subtask)
        New_Tasks.append(New_Task)
    return New_Tasks

Deep_Copy = Manual_Deep_Copy(Project_Tasks)
Deep_Copy[2][2][1][2][1][2][0][1] = "Incomplete"

print("\nAfter Changing Subtask C2b1 in Deep Copy:")
print("Original C2b1 Status:", Project_Tasks[2][2][1][2][1][2][0][1])
print("Deep Copy C2b1 Status:", Deep_Copy[2][2][1][2][1][2][0][1])
print("Original Remains Unchanged because the Deep Copy has Separate Lists.")

Deep_Copy.append([
    "Task D",
    "incomplete",
    [
        ["Subtask D1", "incomplete", []],
        ["Subtask D2", "incomplete", []]
    ]
])

Task_B = Deep_Copy[1][2]
for i in range(len(Task_B)):
    if Task_B[i][0] == "Subtask B1":
        Task_B.pop(i)
        break

Task_A = Deep_Copy[0][2]
for Subtask in Task_A:
    if Subtask[0] == "Subtask A2":
        for Nested in Subtask[2]:
            if Nested[0] == "Subtask A2b":
                Nested[1] = "completed"

print("\nFinal Comparison:")
print("Original Number of Root Tasks:", len(Project_Tasks))
print("Deep Copy Number of Root Tasks:", len(Deep_Copy))
print("Original Task B Subtasks:", Project_Tasks[1][2])
print("Deep Copy Task B Subtasks:", Deep_Copy[1][2])
print("Original A2b Status:", Project_Tasks[0][2][1][2][1][1])
print("Deep Copy A2b Status:", Deep_Copy[0][2][1][2][1][1])
print("Original C2b1 status:", Project_Tasks[2][2][1][2][1][2][0][1])
print("Deep Copy C2b1 Status:", Deep_Copy[2][2][1][2][1][2][0][1])
print("\nTask D in Deep Copy:", Deep_Copy[3])