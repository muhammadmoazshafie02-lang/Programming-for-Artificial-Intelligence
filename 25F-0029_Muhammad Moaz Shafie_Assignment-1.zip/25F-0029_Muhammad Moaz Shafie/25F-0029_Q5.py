Set_A = {101, 202, 303, 404, 505}
Set_B = {303, 404, 606, 707, 808}
Original_Set_A = Set_A.copy()
New_Accounts = [202, 606, 909, 1010]
Set_A.update(New_Accounts)

print("Original Set A:", Original_Set_A)
print("Set A after Adding New Accounts:", Set_A)

Remove_ID = 303
if Remove_ID in Set_A:
    Set_A.remove(Remove_ID)
    print(Remove_ID, "Removed from Set A")
else:
    print(Remove_ID, "does not Exist in Set A")

Set_A.discard(999)
print("Set A after Removal:", Set_A)

Union_Set = Set_A.union(Set_B)
Intersection_Set = Set_A.intersection(Set_B)
Difference_Set = Set_A.difference(Set_B)
Symmetric_Difference_Set = Set_A.symmetric_difference(Set_B)

print("\nUnion:", Union_Set)
print("Intersection:", Intersection_Set)
print("Set A - Set B:", Difference_Set)
print("Symmetric Difference:", Symmetric_Difference_Set)

Check_IDs = [202, 404, 707, 909]
for Account in Check_IDs:
    print("\nChecking Account:", Account)
    if Account in Set_A:
        print("Present in Set A")
    else:
        print("Not Present in Set A")

    if Account in Set_B:
        print("Present in Set B")
    else:
        print("Not Present in Set B")

Threshold = 400
Filtered_Set = {
    Account for Account in Set_A
    if Account > Threshold and Account % 2 == 0
}
print("\nFiltered Set A:", Filtered_Set)

Set_A.clear()
print("\nSet A after Clear:", Set_A)