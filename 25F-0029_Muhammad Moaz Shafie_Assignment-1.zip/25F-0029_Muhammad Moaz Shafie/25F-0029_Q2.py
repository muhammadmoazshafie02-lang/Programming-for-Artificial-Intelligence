Data = (((1, 2, ('A', (3, [4, 5]), 'B')), 6),
        (7, (8, [9, ('C', (10, (11, 12, ('D', (13, [14])))))], 'E'),
        (15, [16, (17, 'F', (18, (19, 20, 21)))])))

print("Original Data:")
print(Data)
print("\n1. Deepest Nested Elements:")

Element_14 = Data[1][1][1][1][1][1][2][1][1][0]
Element_21 = Data[1][2][1][1][2][1][2]

print("Element 14:", Element_14)
print("Element 21:", Element_21)

print("\n2. Flattened Tuple:")

def Flatten(Item):
    Result = []
    if isinstance(Item, (tuple, list)):
        for Element in Item:
            Result.extend(Flatten(Element))
    else:
        Result.append(Item)
    return Result

Flat_Data = Flatten(Data)
print(Flat_Data)

print("\n3. Nested Slicing and Extraction:")
print("First Part:", Data[0])
print("Second Part:", Data[1])
print("First Part Slice:", Data[0][:2])
print("Second Part Slice:", Data[1][:2])
print("Nested Tuple Slice:", Data[0][0][2][:2])
print("Nested List Slice:", Data[0][0][2][1][1][:])

Numeric_Values = []
for Item in Flat_Data:
    if isinstance(Item, int):
        Numeric_Values.append(Item)

print("All Numeric Values:", Numeric_Values)

print("\n4. Tuple Concatenation:")

Extra = (22, 23, ('G', [24, 25]), 26)
Concatenated = Data[1] + Extra

print("Extra:", Extra)
print("Concatenated Tuple:", Concatenated)
print("Length:", len(Concatenated))
print("Elements:")
for Item in Concatenated:
    print(Item)

print("\n5. Repeat and Integrate Sub-Tuple:")

Sub_Tuple = ('A', (3, [4, 5]))
Repeat_Count = 3
Repeated_Tuple = Sub_Tuple * Repeat_Count

print("Sub-Tuple:", Sub_Tuple)
print("Repeated Tuple:", Repeated_Tuple)

Original_First = Data[0][0]
Integrated_Tuple = (
    Original_First[:2] +
    Repeated_Tuple +
    Original_First[2:]
)

print("Integrated Tuple:", Integrated_Tuple)

print("\n6. Tuple Statistics:")
print("Length of data:", len(Data))
print("Length of data[0]:", len(Data[0]))
print("Length of data[1]:", len(Data[1]))
print("Length of extra:", len(Extra))
print("Length of sub_tuple:", len(Sub_Tuple))
print("Count of 6:", Data[0].count(6))
print("Count of 7:", Data[1].count(7))
print("Index of 6:", Data[0].index(6))
print("Index of 7:", Data[1].index(7))

Target_Tuple = Data[0][0][2]

print("Count of target tuple:", Data[0][0].count(Target_Tuple))
print("Index of target tuple:", Data[0][0].index(Target_Tuple))

print("\nIndividual Elements and Positions:")

for i in range(len(Target_Tuple)):
    print("Index:", i, "Value:", Target_Tuple[i])

print("\nNested Tuple Occurrences:")

Target = ('A', (3, [4, 5]))
Count = 0

for Item in Data[0][0]:
    if Item == Target:
        Count += 1

print("Target:", Target)
print("Occurrences:", Count)

print("\n7. Tuple Packing and Unpacking:")

Packed = (100, "Python", [200, 300])

print("Packed Tuple:", Packed)

Number, Language, Numbers = Packed

print("Unpacked Number:", Number)
print("Unpacked Language:", Language)
print("Unpacked List:", Numbers)

Nested_Packed = ("A", (3, [4, 5]))
Letter, Nested_Values = Nested_Packed
Number_3, List_Values = Nested_Values

print("\nNested Unpacking:")
print("Letter:", Letter)
print("Number:", Number_3)
print("List:", List_Values)

A = 10
B = 20
C = 30

Packed_Values = A, B, C

print("\nPacked Multiple Values:", Packed_Values)

X, Y, Z = Packed_Values

print("Unpacked:", X, Y, Z)